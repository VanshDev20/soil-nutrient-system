# 🌱 Soil Nutrient Analysis System

A production-ready REST API built with Node.js (Express) + MySQL for analyzing soil nutrients and recommending crops and fertilizers.

---

## 📁 Folder Structure

```
soil-nutrient-system/
├── config/
│   ├── db.js               # MySQL connection pool
│   └── migrate.js          # Database schema migration script
├── controllers/
│   ├── auth.controller.js  # Auth request handlers
│   └── soil.controller.js  # Soil analysis request handlers
├── middlewares/
│   ├── auth.middleware.js  # JWT authentication + role authorization
│   ├── validate.middleware.js  # express-validator error formatter
│   └── error.middleware.js # Global error handler + 404
├── models/
│   ├── user.model.js       # User DB queries
│   └── soilReport.model.js # Soil report DB queries
├── routes/
│   ├── auth.routes.js      # /api/auth/*
│   └── soil.routes.js      # /api/soil/*
├── services/
│   ├── auth.service.js     # Signup / login business logic
│   └── soil.service.js     # Analysis logic + crop/fertilizer engine
├── utils/
│   ├── jwt.js              # Sign / verify JWT
│   ├── response.js         # Standardised JSON response helpers
│   └── logger.js           # Lightweight console logger
├── app.js                  # Express app setup (middleware, routes)
├── server.js               # Entry point — DB check + graceful shutdown
├── .env.example            # Environment variable template
└── package.json
```

---

## 🗄️ MySQL Schema

```sql
CREATE DATABASE IF NOT EXISTS `soil_nutrient_db`;
USE `soil_nutrient_db`;

CREATE TABLE IF NOT EXISTS users (
  id          INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  name        VARCHAR(100)    NOT NULL,
  email       VARCHAR(150)    NOT NULL UNIQUE,
  password    VARCHAR(255)    NOT NULL,
  role        ENUM('user','admin') NOT NULL DEFAULT 'user',
  created_at  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS soil_reports (
  id                  INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  user_id             INT UNSIGNED    NOT NULL,
  nitrogen            DECIMAL(6,2)    NOT NULL COMMENT 'mg/kg',
  phosphorus          DECIMAL(6,2)    NOT NULL COMMENT 'mg/kg',
  potassium           DECIMAL(6,2)    NOT NULL COMMENT 'mg/kg',
  ph                  DECIMAL(4,2)    NOT NULL,
  soil_type           VARCHAR(50)     NOT NULL,
  fertilizer_suggestion TEXT          NOT NULL,
  crop_recommendation TEXT            NOT NULL,
  notes               TEXT            NULL,
  created_at          TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  INDEX idx_user_id (user_id),
  CONSTRAINT fk_soil_reports_user
    FOREIGN KEY (user_id) REFERENCES users (id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

---

## ⚙️ Setup & Run

### 1. Clone & install dependencies
```bash
git clone <repo-url>
cd soil-nutrient-system
npm install
```

### 2. Configure environment
```bash
cp .env.example .env
# Edit .env with your MySQL credentials and a strong JWT_SECRET
```

### 3. Run database migration
```bash
npm run db:migrate
```

### 4. Start the server
```bash
# Development (auto-reload)
npm run dev

# Production
npm start
```

Server starts at: `http://localhost:3000`  
Health check: `GET http://localhost:3000/health`

---

## 🔐 Environment Variables

| Variable | Description | Example |
|---|---|---|
| `PORT` | Server port | `3000` |
| `NODE_ENV` | Environment | `development` |
| `DB_HOST` | MySQL host | `localhost` |
| `DB_PORT` | MySQL port | `3306` |
| `DB_USER` | MySQL user | `root` |
| `DB_PASSWORD` | MySQL password | `secret` |
| `DB_NAME` | Database name | `soil_nutrient_db` |
| `JWT_SECRET` | JWT signing secret (min 32 chars) | `super_secret_key_abc123...` |
| `JWT_EXPIRES_IN` | Token TTL | `7d` |
| `RATE_LIMIT_WINDOW_MS` | Rate limit window (ms) | `900000` |
| `RATE_LIMIT_MAX` | Max requests per window | `100` |

---

## 📡 API Endpoints

### Base URL: `http://localhost:3000`

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/health` | No | Health check |
| POST | `/api/auth/signup` | No | Register a new user |
| POST | `/api/auth/login` | No | Login and get JWT |
| GET | `/api/auth/me` | ✅ Bearer | Get current user profile |
| POST | `/api/soil/analyze` | ✅ Bearer | Analyze soil and save report |
| GET | `/api/soil/history` | ✅ Bearer | Get paginated history |

---

## 📬 Postman Examples

### 1. Health Check
```
GET http://localhost:3000/health
```
**Response:**
```json
{
  "success": true,
  "message": "Soil Nutrient Analysis API is running.",
  "data": {
    "environment": "development",
    "timestamp": "2026-04-22T10:00:00.000Z"
  }
}
```

---

### 2. Sign Up
```
POST http://localhost:3000/api/auth/signup
Content-Type: application/json
```
**Body:**
```json
{
  "name": "Arjun Sharma",
  "email": "arjun@example.com",
  "password": "Secure@1234"
}
```
**Response (201):**
```json
{
  "success": true,
  "message": "Account created successfully.",
  "data": {
    "user": {
      "id": 1,
      "name": "Arjun Sharma",
      "email": "arjun@example.com",
      "role": "user"
    },
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

---

### 3. Login
```
POST http://localhost:3000/api/auth/login
Content-Type: application/json
```
**Body:**
```json
{
  "email": "arjun@example.com",
  "password": "Secure@1234"
}
```
**Response (200):**
```json
{
  "success": true,
  "message": "Login successful.",
  "data": {
    "user": {
      "id": 1,
      "name": "Arjun Sharma",
      "email": "arjun@example.com",
      "role": "user",
      "created_at": "2026-04-22T10:00:00.000Z"
    },
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

---

### 4. Analyze Soil ✅ Protected
```
POST http://localhost:3000/api/soil/analyze
Content-Type: application/json
Authorization: Bearer <your_token>
```
**Body:**
```json
{
  "nitrogen": 120,
  "phosphorus": 8,
  "potassium": 200,
  "ph": 6.2,
  "notes": "Sample from north field, post-monsoon"
}
```
**Response (201):**
```json
{
  "success": true,
  "message": "Soil analysis completed successfully.",
  "data": {
    "report": {
      "id": 1,
      "user_id": 1,
      "nitrogen": "120.00",
      "phosphorus": "8.00",
      "potassium": "200.00",
      "ph": "6.20",
      "soil_type": "Mildly Acidic",
      "fertilizer_suggestion": "Apply Urea (46-0-0) or Ammonium Nitrate to boost nitrogen. Apply Single Super Phosphate (SSP) or DAP to increase phosphorus.",
      "crop_recommendation": "Rice, Potato, Tea, Blueberry, Oats, Banana, Sugarcane",
      "notes": "Sample from north field, post-monsoon",
      "created_at": "2026-04-22T10:05:00.000Z",
      "analysis_summary": {
        "nitrogen_level": "low",
        "phosphorus_level": "low",
        "potassium_level": "optimal",
        "soil_description": "pH 5.5–6.5 — mildly acidic soil"
      }
    }
  }
}
```

---

### 5. Get Soil History ✅ Protected
```
GET http://localhost:3000/api/soil/history?page=1&limit=5
Authorization: Bearer <your_token>
```
**Response (200):**
```json
{
  "success": true,
  "message": "Soil analysis history retrieved successfully.",
  "data": {
    "reports": [
      {
        "id": 1,
        "user_id": 1,
        "nitrogen": "120.00",
        "phosphorus": "8.00",
        "potassium": "200.00",
        "ph": "6.20",
        "soil_type": "Mildly Acidic",
        "fertilizer_suggestion": "...",
        "crop_recommendation": "Rice, Potato, Tea...",
        "notes": "Sample from north field",
        "created_at": "2026-04-22T10:05:00.000Z"
      }
    ]
  },
  "meta": {
    "total": 1,
    "page": 1,
    "limit": 5,
    "totalPages": 1,
    "hasNextPage": false,
    "hasPrevPage": false
  }
}
```

---

### 6. Validation Error Example
```
POST http://localhost:3000/api/soil/analyze
Authorization: Bearer <your_token>
Content-Type: application/json
```
**Body (invalid):**
```json
{
  "nitrogen": -10,
  "ph": 20
}
```
**Response (422):**
```json
{
  "success": false,
  "message": "Validation failed.",
  "errors": [
    { "field": "nitrogen",   "message": "Nitrogen must be a number between 0 and 1000 mg/kg." },
    { "field": "phosphorus", "message": "Phosphorus value is required." },
    { "field": "potassium",  "message": "Potassium value is required." },
    { "field": "ph",         "message": "pH must be a number between 0 and 14." }
  ]
}
```

---

## 🧠 Soil Analysis Logic

### pH Classification
| pH Range | Soil Type |
|---|---|
| < 5.5 | Strongly Acidic |
| 5.5 – 6.5 | Mildly Acidic |
| 6.5 – 7.5 | Neutral |
| 7.5 – 8.5 | Mildly Alkaline |
| > 8.5 | Strongly Alkaline |

### Nutrient Thresholds (mg/kg)
| Nutrient | Low | Optimal | High |
|---|---|---|---|
| Nitrogen | < 140 | 140–280 | > 280 |
| Phosphorus | < 10 | 10–30 | > 30 |
| Potassium | < 120 | 120–250 | > 250 |

---

## 🔒 Security Features

- **Helmet** — sets secure HTTP headers
- **Rate Limiting** — 100 req/15 min globally; 20 req/15 min on auth routes
- **JWT** — stateless auth with expiry
- **bcryptjs** — passwords hashed with 12 salt rounds
- **Input Validation** — express-validator on all inputs
- **JSON size limit** — body capped at 10kb
- **Graceful shutdown** — SIGTERM/SIGINT handled cleanly
